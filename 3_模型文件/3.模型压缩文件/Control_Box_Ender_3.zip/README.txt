                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3072566
Control Box Ender 3 by jakinoh is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

# Version 0.3
---

Octoprint is important to control your 3D printer. I designed a box to add new features to my ender 3 like: 

- Have remote control of the printer from your smartphone ( Printoid)
- Turn your printer on or off
- Turn the light on or off (useful when a camera is installed) 
see link below to understand and add this feature to OctoPrint 
https://github.com/foosel/OctoPrint/wiki/Controlling-a-relay-board-from-your-RPi
- the progress of the program to control the internal fans. It is possible for the moment to switch it on via WiringPi ( Gpio write 4 1 or 4 0). The idea is to be able to adjust the fan speed according to the internal temperature of the box


To be coming soon: 
- Control the ventilation of the enclosure via the Gcode controls and according to DHT22 sensor



---
**This box is designed to include :**
- 1X Raspberry Pi 2 or 3 // https://amzn.to/2CZGA9x // 
- 2X DC DC converter ( Ref LM2596) // https://amzn.to/2D2AW6T // 
- 4X WAGO 221 connectors // https://amzn.to/2zsuEd2 // 
- 1X relay to control the lighting // https://amzn.to/2Oo9wdl // 
- 1X Relay 30a to control the printer // https://amzn.to/2OnNjMO // 
- 2X 12V 40mm fan // https://amzn.to/2D0HK4T //
- 3X BC549 Transistor // https://amzn.to/2zoJ3XW //
- 4X XT60 Connector // https://amzn.to/2PFuGbE //

*To assemble all this, you will need:*
- 3,5mmx12mm screws x16 // https://amzn.to/2OnOgom //

a wiring diagram is available for connecting the different components 

---

# Updates

**Version 0.3**
- Added a 30a relay to control the printer power supply
- Improvement of XT60 fasteners
- Expansion of the dupont connector location
- Modification of the fixing rail


**version 0.2 :**
- Increase in the size of the box, following the first assembly.... More space for easy wiring.
- Addition of a guide on the side to be fixed in the Bosch profile
- Modification of the mounting system for LM2596 converters
- Adding an additional wago connector
- Adding a wiring diagram 
- Addition of 4 clipped XT60 connectors
- Adding a 10-pin dupont connector 



# Print Settings

Printer Brand: Creality
Printer: Ender 3
Rafts: No
Supports: No
Resolution: 0,2
Infill: 30