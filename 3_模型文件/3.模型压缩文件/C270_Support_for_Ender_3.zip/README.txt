                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2996256
C270 Support for Ender 3 by Waverunner62 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Hi,

First, thanks to read me and sorry for my bad english.

This mount is for a Logitech C270 on Ender 3 printer.

Parts printed:
1     Base_C270_Printer_v5_v5.stl ( ABS) or 1 Base45_C270_Printer v8 ( PLA or ABS )
3     Arm_C270_v5.stl 
1     C270_cam_side_v4.stl

Nuts and Bolts

CHC M4 x 30
Nuts  Nylstop M4
see the pics because those are french designation

No mods on cam or on Printer, no holes to do, just use of tie wrap or existing screw
Base45_C270_Printer v8 is stronger than Base_C270_Printer_v5_v5.stl and  give more acces to the bed


Leds light coming too. 

ALWAYS in WORK IN PROGRESS !!!!!

I suppose most of the parts can be used on other printers with a bit of remix

Best regards

Eric


########################################################################


Bonjour a tous

Ce support est fait pour utiliser votre C270 Logitech directement sur Ender 3.
Aucune modification n"est requise sur l'imprimante , ni sur la camera.
Il suffit de 3 tie wrap pour maintenir le tout ou  d'utiliser les vis existantes (voir photos).

Le support de la camera sera ultérieurement surmonté d'un Eclairage 12 LED.

Eléments imprimés:
1     Base_C270_Printer_v5_v5.stl ( ABS) ou 1 Base45_C270_Printer v8 ( PLA ou ABS )
3     Arm_C270_v5.stl 
1     C270_cam_side_v4.stl

Vis CHC M4 x 30 et ecrous Nylstop M4

Base45_C270_Printer v8 est plus qolide que la Base_C270_Printer_v5_v5.stl et degage aussi plus d'accés au lit chauffant.

A suivre

ATTENTION WIP WORK IN PROGRESS, Travail en Cours !!!

bonnes impressions

N’hésitez pas a me contacter en commentaire pour les fichiers fusion360

Eric



# Print Settings

Printer Brand: Creality
Printer: Ender 3
Rafts: Doesn't Matter
Supports: No
Resolution: 0,2mm
Infill: 20%

# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/51/b3/4f/5b/5f/20180709_000507.jpg)

![Alt text](https://cdn.thingiverse.com/assets/27/6f/0b/da/90/20180709_000455.jpg)

![Alt text](https://cdn.thingiverse.com/assets/b3/55/96/d7/5a/20180709_000329.jpg)

![Alt text](https://cdn.thingiverse.com/assets/af/d0/41/86/7d/20180709_000603.jpg)

![Alt text](https://cdn.thingiverse.com/assets/29/69/ea/d4/5c/20180710_124913.jpg)

![Alt text](https://cdn.thingiverse.com/assets/8e/83/c8/86/b4/20180710_125211.jpg)

![Alt text](https://cdn.thingiverse.com/assets/c0/af/f2/9e/bd/20180712_143011.jpg)

![Alt text](https://cdn.thingiverse.com/assets/cb/c1/fa/9d/0f/20180714_144327.jpg)

![Alt text](https://cdn.thingiverse.com/assets/f7/18/a9/2d/f5/20180714_144839.jpg)