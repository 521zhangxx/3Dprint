                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2886101
Creality Ender 3 Pi Cam Mount by Modmike is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

### IMPORTANT!!!!!!!!!

TEST FIT THE CASE BEFORE INSTALLING THE CAMERA OR YOU MAY BREAK IT.  THE COVER SHOULD SLIDE ON WITH SOME RESISTANCE.  IF IT IS TOO HARD YOU NEED TO CALIBRATE YOUR PRINER.  REMOVE AND REINSTALL THE COVER  3 OR 4 TIMES TO MAKE SURE EVERYTHING FITS.

The case has many small features and tolerances need to be tight.  I've had a few people complaining about tight tolerances and difficult fitment.  Some of you even feel it is ok to be angry with me.  

Your printer must be properly calibrated for proper fitment.  In most cases this is simply a matter of adjusting the flow rate in your slicer.  I would recommend a full calibration but this may be hard for those of you who are uncomfortable with compiling and flashing Marlin.  This can be especially difficult on an Ender 3.

That being said you can probably get very close to perfection by adjusting the flow rate for every filament brand you get.  Yes every brand.  Despite their accuracy claims filament widths can vary wildly.  I remember one roll varied from 1.6 to 1.9.  Couldn't understand why my prints weren't working until I measured it in several places.

### How to calibrate your flow rate for accurately sized prints

If you don't have digital callipers, you can always start by reducing your flow rate to 90% (or .9 in S3D) and see how that works.

This is probably the easiest Ender 3 based guide I've seen:   

https://www.youtube.com/watch?v=3yIebnVjADM

###Introduction

The Ender 3 features a new molded plastic cap for the X-axis stepper motor that replaces the previous acrylic one.  This obsoletes previous mounts so I designed a new one I hope you will like.


### Design goals:

1. Create a solid mount that is easy to attach and remove
2. Minimize printing time 
3. Keep hardware requirements to a minimum
4. Create a solid Pi Cam housing that allows the focus to be set without ripping the base off


### Hardware required:

1. Pi Cam 1, 2, or 2.1 (Be sure to use proper camera housing))
2. M4 15mm housing mounting bolt
3. M4 15mm arm locking bolt (optional)


### Building:

Attach the mount by hooking the right corner first and then clipping the left one on.  You can slide the whole assembly up and down to adjust height, I installed mine in the middle.

The fit should be very tight but i've included a 15mm M4 bolt hole in the spring arm to secure it in place if you wish.

#### Mounting the Pi Cam:

Pi Cam camera sensors are attached with a flex cable and self adhesive glue, which Makes for unpredictable fitment.  I recommend that you do not stick the sensor to the back or at least separate it before you insert it into the case so that it can line up with the built in sensor frame. The point of the tight frame is to provide support so it does not get twisted off the base when you focus it, which you will have to do.

#### Focusing the Pi Cam:

Pi Cam's are typically set to infinty focus at the factory and glued in place.  Be patient and remove any obvious glue in between the lens and square lens mount, then fit it securely in the housing.

Use a focusing tool such as this one:

https://www.thingiverse.com/thing:1570865

to turn it clockwise.  Make a quarter turn then test, repeat until happy.  I recommend you have the head in the middle of the bed and hold the camera at the edge for your tests.


### Comments:

There are many clones and vendors out there so dimensions will vary.   I used the official Pi Cam 1 & 2 mechanical drawings, if yours does not fit, please let me know.  I am not promising to fix it, I just will try to come up with a relaxed fit design.

### Files

Bracket - Version 1 of the mount.  Use this one if you do not need extra clearance.

Bracket Style 2 - A special version of the bracket for extra clearance.

Housing Front - PiCam 1 front housing

Housing Back - PiCam 1 rear housing

PiCam 2 Front housing - Fits standard PiCam 2

PiCam 2 Rear housing flipped - For a strange version of the PiCam that has front camera flipped 180 degrees.

PiCam 2 rear housing - Rear housing for PiCam 2 and PiCam 2 flipped

#### Raspberry Pi & Touchscreen

If you have an RPi with touch screen mounted on the left and need even more clearance, try this very nice derivative mount by Tronnic :

https://www.thingiverse.com/thing:3030160

Please note that I've specifically allowed this derivative and exempted it from the restrictions of my creative commons license.

# Print Settings

Printer Brand: Creality
Printer: Ender 3
Rafts: No
Supports: No
Resolution: .2
Infill: 30
Filament_brand: AMZ3D
Filament_color: Black
Filament_material: PLA

Notes: 
This thingy has small parts and tight tolerances.  It is critical that you print using a carefully levelled bed and properly calibrated printer for good fitment.  If you are unsure, print a test cube and measure the results. I use this one but any 20 by 20 cube will work.

https://www.thingiverse.com/thing:277394

The front housing is printed flat with the lens hole flat on the bed.

The rear needs to be printed standing up with mounting lug on the bed.  Have printed it several times like that with no issue.