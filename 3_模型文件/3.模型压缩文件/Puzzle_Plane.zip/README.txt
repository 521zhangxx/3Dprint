                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3255904
Puzzle Plane by Deemoss is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

A puzzle plane held together by magnets!

DISCLAIMER

** Magnets can potentially become loose and since they are small they can be a hazard to  young kids. Therefore this design is not suitable for 0-3 year olds.** https://www.org/English/safety-prevention/at-home/Pages/Dangers-of-Magnetic-Toys-and-Fake-Piercings.aspx

DESCRIPTION

The only thing that you will need other than plastic are the magnets (3mm tall, 6mm diameter). There are 63 magnet sockets in total but I used probably 55 magnets.

Dimensions (L x W x H): 217mn x 255mm x 116mm

Cut up for minimal support requirement. I glued the magnets in the pockets with CA clue and it worked quite well, but care need so be taken because any leaks can glue the plastic parts together.

**Magnet glueing tips:** https://www.kjmagnetics.com/blog.asp?p=sticky-business-how-to-glue-neodymum-magnets

You can order the plastic parts ready printed here: https://www.ebay.co.uk/itm/333009134933