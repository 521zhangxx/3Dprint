                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2134321
Rick Sanchez [Rick and Morty] by ChaosCoreTech is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Watch here: https://youtu.be/R97du7G9WG4 

Edit: I accidentally uploaded the wrong file. The new file has been uploaded, the new one has just been scaled up to a normal-ish size and I cut off a bit of the feet to make him stand on his own. :)

Any fans of Rick and Morty out there? I hope so because today I bring you Rick Sanchez. He's just in a standing pose, holding a flask, and having a dull, not interested look on his face.

I created the model in ZBrush Core. This is actually the first full model I've done in this program, so it was quite the learning experience.

Then my wife painted it using filler primer, followed by some acrylic paints and then topped the whole thing off with a clear coat.

Print Settings:
Printer: XYZprinting Da Vinci 1.0 Pro
Filament: Hatchbox PLA
Layer Height: 0.1mm
Infill: 20%
Supports/Raft: Yes