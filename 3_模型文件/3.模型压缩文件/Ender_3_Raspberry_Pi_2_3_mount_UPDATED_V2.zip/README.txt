                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3016364
Ender 3 Raspberry Pi 2/3 mount (UPDATED V2) by giacomo30196 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Ender 3 Raspberry Pi 2/3 mount 
=========================

_07/10/2018_
30mm fan added

THERE IS NOW A 2 RAILS VERSION: https://www.thingiverse.com/thing:3075921

UPDATED V2 
Basically i switched the front and the back, I find it to be stronger.
V2 FILES ARE NOT COMPATIBLE WITH V1


I made this Raspberry Pi mount for the Ender 3 because i didn't want to use screws and I wanted the hole for the RasPi Camera. 
Since I'm planning to leave it always on, I decided to put a 40mm fan wich 
gives me a temperature drop of 10-15 degrees  (during a print it stays at 42 °C with a room temperature of 28 °C). 
However I included a version of the top mount without the fan hole in case you don't want it.

This box can be easily slide into the Ender 3 frame as shown in the photo. You only have to remove the 2 screws wich are holding the printer screen.

To design it I used this model of the Raspberry Pi that is incredibly detailed and well built. https://grabcad.com/library/raspberry-pi-3-model-b-reference-design-rpi-raspberrypi-raspberry-pi-solidworks-cad-assembly-1
and this fan https://grabcad.com/library/fan-40-x-40-mm-1


Any suggestion on how to improve it is very welcome.


If you have any doubt, do not hesitate to contact me, I'll try my best to help you.

_____________________________________________________________

__If you like what I do and want to support me, head to https://www.paypal.me/giacomo30196 every bit helps me to make more things for you.__
__THANK YOU!__
_____________________________________________________________

# Print Settings

Printer: Creality3D Ender3